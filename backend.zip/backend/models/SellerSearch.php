<?php

namespace backend\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use backend\models\Seller;

/**
 * SellerSearch represents the model behind the search form about `backend\models\Seller`.
 */
class SellerSearch extends Seller
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['UserId'], 'integer'],
            [['UserName', 'Email', 'Password', 'Mobile', 'ProfilePic', 'FirstName', 'LastName', 'Gender', 'LogInStatus', 'LastLogin', 'ResetToken', 'AccessToken', 'Status', 'CreatedOn', 'UpdatedOn'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Seller::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'UserId' => $this->UserId,
            'LastLogin' => $this->LastLogin,
            'CreatedOn' => $this->CreatedOn,
            'UpdatedOn' => $this->UpdatedOn,
        ]);

        $query->andFilterWhere(['like', 'UserName', $this->UserName])
            ->andFilterWhere(['like', 'Email', $this->Email])
            ->andFilterWhere(['like', 'Password', $this->Password])
            ->andFilterWhere(['like', 'Mobile', $this->Mobile])
            ->andFilterWhere(['like', 'ProfilePic', $this->ProfilePic])
            ->andFilterWhere(['like', 'FirstName', $this->FirstName])
            ->andFilterWhere(['like', 'LastName', $this->LastName])
            ->andFilterWhere(['like', 'Gender', $this->Gender])
            ->andFilterWhere(['like', 'LogInStatus', $this->LogInStatus])
            ->andFilterWhere(['like', 'ResetToken', $this->ResetToken])
            ->andFilterWhere(['like', 'AccessToken', $this->AccessToken])
            ->andFilterWhere(['like', 'Status', $this->Status]);

        return $dataProvider;
    }
}
