<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
use kartik\export\ExportMenu;

/* @var $this yii\web\View */
/* @var $searchModel backend\models\PartdetailSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Part Details';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="partdetail-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Part Detail', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?php 
	
	$gridColumns = [
		['class' => 'yii\grid\SerialColumn'],
		'PartName',
		'PartCondition',
		'PartMfgYear',
		'user.UserName',
		'partType.part_type_name',
		'vehiclemake.MakeName',
		'vehicleModel.ModelName',
		'Status'
	];
	
	echo ExportMenu::widget([
		'dataProvider' => $dataProvider,
		'filterModel' => $searchModel,
		'columns' => $gridColumns
	]);
	
	?>
    <?php Pjax::begin(); ?>
	<?=
	GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'PartName:ntext',
            'PartCondition',
            'PartMfgYear',
			[
				'attribute' => 'UserId',
				'value' => 'user.UserName',
   			],
			[
				'attribute' => 'PartTypeId',
				'value' => 'partType.part_type_name',
   			],
			[
				'attribute' => 'VehiclemakeId',
				'value' => 'vehiclemake.MakeName',
   			],
			[
				'attribute' => 'VehicleModelId',
				'value' => 'vehicleModel.ModelName',
   			],				
            // 'Lat',
            // 'Lng',
            // 'Location',
            'Status',
            // 'CreatedOn',
            // 'UpdatedOn',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
    <?php Pjax::end(); ?>
</div>
