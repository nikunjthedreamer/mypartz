<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model backend\models\Partdetail */

$this->title = '';
$this->params['breadcrumbs'][] = ['label' => 'Part Detail', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="partdetail-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->PartId], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->PartId], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            //'PartId',
            'PartName:ntext',
            'PartDetails:ntext',
            'PartCondition',
            'PartMfgYear',
            //'UserId',
            //'PartTypeId',
            //'VehiclemakeId',
            //'VehicleModelId',
            //'Lat',
            //'Lng',
            //'Location',
            'Status',
            //'CreatedOn',
            //'UpdatedOn',
        ],
    ]) ?>

</div>
